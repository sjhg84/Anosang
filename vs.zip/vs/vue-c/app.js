import Tickets from './components/Tickets.js'
import Modal from './components/Modal.js'

const app = Vue.createApp({
  template: `
      <h2> {{ message }} </h2>
      <Modal />
      <Tickets gsheetId="1-Qd3YBy4Oxy9qNXRsbHsfmF-tzpH9V_0GIRuU14xQzE" 
      gsheetTab="Tickets" gsheetApi="AIzaSyC7w5L8yL4rpdBsr86_ukMkhTIekmk4uHI" />
    `,
  data() {
    return {
      message: 'Hello from Main App!',
    };
  },
  components: { Tickets, Modal },
});

app.mount('#app');

