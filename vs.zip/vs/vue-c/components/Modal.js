export default {
    template: `
    <h1>{{ header }}</h1>
    `,
    data() {
        return {
            header: 'My header is here!'
        }
    },
};