export default {
  template: `
  <div class="tickets" v-if="showTickets">
  <link rel="stylesheet" href="./assets/tickets.css">
      <div v-for="ticket in sortedTickets" :key="ticket.order"
      :class="[{'featured': ticket.isfeatured === 'TRUE'}, 'category-' + ticket.category.toLowerCase()]">
          <h3>{{ ticket.category }}</h3>
          <p>{{ ticket.doorprice }}</p>
          <h3>{{ ticket.price }}</h3>
          <ul>
              <li v-for="(item, index) in ticket.includedArray" :key="index">{{ item }}</li>
          </ul>
          <a class="ticket-btn" :href="ticket.url">BUY NOW</a>
      </div>
  </div>
  `,
  data() {
    return {
      showTickets: false,
      tickets: [],
    };
  },
  props: ['appScript', 'gsheetId', 'gsheetTab', 'gsheetApi'],
  computed: {
    sortedTickets() {
      return this.tickets.sort((a, b) => Number(a.order) - Number(b.order));
    }
  },
  mounted() {
    this.fetchTickets();
  },
  methods: {
    fetchTickets() {
      fetch(`https://sheets.googleapis.com/v4/spreadsheets/${this.gsheetId}/values/${this.gsheetTab}/?alt=json&key=${this.gsheetApi}`)
      //fetch(this.appScript)
        .then(res => res.json())
        .then(data => {
          //console.log(data)
          this.tickets = this.transformData(data);
          console.log(this.tickets)
          // this.tickets = data.map(ticket => {
          //   return Object.keys(ticket).reduce((newObj, key) => {
          //     newObj[key.toLowerCase()] = ticket[key];  // Convert key to lowercase and copy value
          //     return newObj;
          //   }, {});
          // });
          this.showTickets = true;
        })
        .catch(error => console.error('Error loading tickets:', error));
    },
    transformData(data) {
      const headers = data.values[0];
      return data.values.slice(1).map(row => {
        let rowObj = headers.reduce((obj, header, index) => {
          obj[header.toLowerCase()] = row[index];
          return obj;
        }, {});
        if (rowObj.included) {
          rowObj.includedArray = rowObj.included.split('\n').map(item => item.trim().replace(/["]+/g, ''));
        }
        return rowObj;
      });
    }
  }
};
