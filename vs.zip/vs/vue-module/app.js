import GreetingComponent from './components/testing.js'; 

const { createApp } = Vue;

const app = createApp({
  data() {
    return {
      message: 'Hello from Main App!'
    };
  },
  components: {
    'greeting-component': GreetingComponent
  }
});

app.mount('#app');