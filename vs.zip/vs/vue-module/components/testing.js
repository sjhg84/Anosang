export default {
    data() {
      return {
        greeting: 'Hello from Component!'
      };
    },
    template: `<div>{{ greeting }}</div>`
  };