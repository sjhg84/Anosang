const app = Vue.createApp({
    //data, functions, events
    // template: '<h2>I am the template</h2>'
    data() {
        return {
            showTickets: true,
            tickets: [
                {
                    category: 'General',
                    doorprice: 'RM 1997',
                    price: 'RM 97',
                    url: 'http://www.sr.com/general',
                    isFeatured: true,
                },
                {
                    category: 'VIP',
                    doorprice: 'RM 2997',
                    price: 'RM 197',
                    url: 'http://www.sr.com/vip',
                    isFeatured: false,
                },
                {
                    category: 'Premiums',
                    doorprice: 'RM 3997',
                    price: 'RM 397',
                    url: 'http://www.sr.com/premiums',
                    isFeatured: false,
                },
            ]
        }
    }
})

app.mount("#tickets")